from mylists import *
from check import *

paragraph="The quick brown fox jumped over the lazy dog."
if(checkSentence(paragraph)):
    print("Sentence syntax is correct!")
else:
    print("Secntence syntax is incorrect!")
pronouns=mylistas("pronouns")
adverbs=mylistas("adverbs")
verbs=mylistas("verbs")
helpingverbs=mylistas("helpingverbs")
prepositions=mylistas("prepositions")
conjunctions=mylistas("conjunctions")
interjections=mylistas("interjections")
word=""
words=[]
for a in paragraph:
    if a==' ':
        words.append(word)
        word=""
        continue
    elif a == '.':
        words.append(word)
        word=""
        continue
    elif a == ',':
        words.append(word)
        word=""
        continue
    elif a == "":
        words.append(word)
        word=""
        continue
    word=word+a
notnouns=[]
for a in pronouns:
    if(a in words):
        notnouns.append(a)
for a in adverbs:
    if(a in words):
        notnouns.append(a)
for a in verbs:
    if(a in words):
        notnouns.append(a)
for a in helpingverbs:
    if(a in words):
        notnouns.append(a)
for a in prepositions:
    if(a in words):
        notnouns.append(a)
for a in conjunctions:
    if(a in words):
        notnouns.append(a)
for a in interjections:
    if(a in words):
        notnouns.append(a)
print(notnouns)
nouns=[]
sentence=""
for a in words:
    if a in notnouns:
        sentence= sentence+' _____________ '
        continue
    nouns.append(a)
    sentence=sentence+a+" "
sentence=sentence+"."
print(sentence)
